import Jogo.Jogo;

public class Testes {
    public static void main(String[] args){ new Jogo(); }
}
